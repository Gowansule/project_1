function showMessage(){
    const messageElement =document.getElementById('message');
    messageElement.textContent='Login successful';

}
document.getElementById('messageBox').addEventListener('click',showMessage);
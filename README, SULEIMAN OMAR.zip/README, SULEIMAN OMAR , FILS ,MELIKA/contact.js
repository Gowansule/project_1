function showMessage(){
    const messageElement =document.getElementById('message');
    messageElement.textContent='Thank you For Contacting Us';

}
document.getElementById('Messagebox').addEventListener('click',showMessage);